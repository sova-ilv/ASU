package valdez_hw02;

/**
 * A java enumeration file - TrainStation Completion time : 20 minutes
 *
 * @author Jess Valdez
 * @version (1.0)
 */
public enum TrainStation {
    AMS,
    BRU,
    CPH,
    DUS,
    FRA,
    LHR,
    RWA,
    VIE;

    public static String getTrainStationCity(TrainStation a) {
        switch (a) {
            case AMS:
                return "Amsterdam";
            case BRU:
                return "Brussels";
            case CPH:
                return "Copenhagen";
            case DUS:
                return "Dusseldorf";
            case FRA:
                return "Frankfurt";
            case LHR:
                return "London";
            case RWA:
                return "Warsaw";
            case VIE:
                return "Vienna";
        }
        return "train station not found.";
    }
}
