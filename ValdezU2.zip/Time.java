package valdez_hw02;

/**
 * Time.java - A class that models all travel and destination times.
 *
 * @author Jess Valdez
 * @version (1.0)
 */
public class Time {

    private int hour;
    private int minute;

    Time() {
        hour = 12;
        minute = 0;
    }

    Time(int hour, int minute) {
        this.hour = hour;
        this.minute = minute;
        toString();
    }

    //copy constructor
    public Time(Time anotherTime) {
        this(anotherTime.getHour(), anotherTime.getMinute());
    }

    public int getHour() {
        return hour;
    }

    public int getMinute() {
        return minute;
    }

    public void addHours(int addedHour) {
        hour += addedHour;
        if (hour > 24) {
            hour = 1;
        }
    }

    public void addMinutes(int addedMinute) {
        double hr_multiple = addedMinute / 60.0;
        hour += (int) hr_multiple;

        double d_r_min;
        int r_min;
        //if we add minutes that is > 60 (1Hr)
        if (hr_multiple > 1.0) {
            //d_r_min = ((addedMinute % 60) * 60.0) + 0.5;
            d_r_min = hr_multiple - (int) hr_multiple;
            d_r_min = (d_r_min * 60.0) + 0.5;

            r_min = (int) d_r_min;
            this.minute += r_min;
        } else {
            this.minute += addedMinute;
        }
        if (this.minute > 59) {
            this.minute = this.minute - 60;
            this.hour += 1;
        }

    }

    public boolean addTime(Time anotherTime) {
        this.hour += anotherTime.getHour();
        this.minute += anotherTime.getMinute();
        if (this.minute > 59) {
            this.minute = this.minute - 60;
            this.hour += 1;
        }
        return true;
    }

    public Time getCopy() {
        Time anotherTime = new Time();
        anotherTime.hour = this.getHour();
        anotherTime.minute = this.getMinute();

        return anotherTime;
    }

    public boolean isEarlierThan(Time T) {
        int T_hr_min;
        int C_hr_min;

        T_hr_min = (T.hour * 60) + T.minute;
        C_hr_min = (this.hour * 60) + this.minute;

        if (C_hr_min < T_hr_min) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isLaterThan(Time T) {
        int T_hr_min;
        int C_hr_min;

        T_hr_min = (T.hour * 60) + T.minute;
        C_hr_min = (this.hour * 60) + this.minute;

        if (C_hr_min > T_hr_min) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isSameTime(Time T) {
        int T_hr_min;
        int C_hr_min;

        T_hr_min = (T.hour * 60) + T.minute;
        C_hr_min = (this.hour * 60) + this.minute;

        if (C_hr_min == T_hr_min) {
            return true;
        } else {
            return false;
        }

    }

    public String toString() {

        return formatDigits();
    }

    ////10:50AM
    private String formatDigits() {
        String outstr;
        String ampm;

        if (this.hour < 12) {
            ampm = "AM";
        } else {
            ampm = "PM";
        }

        //12-hour time
        int twelve_hour_time;
        if (this.hour == 0) {
            twelve_hour_time = 12;
        } else {
            twelve_hour_time = this.hour;
        }

        if (this.hour < 13) {
            outstr = String.format("%d:%02d%s", twelve_hour_time, this.minute, ampm);
        } else {
            outstr = String.format("%d:%02d%s", twelve_hour_time - 12, this.minute, ampm);
        }

        return outstr;
    }

}
