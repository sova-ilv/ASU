/**
 * This class will represent a train route between two train stations, using a
 * specific Train, and departing at a specific Time.
 *
 * @author Jess Valdez
 * @version (1.0)
 */
package valdez_hw02;

import static valdez_hw02.TrainStation.getTrainStationCity;
import java.text.NumberFormat;

public class TrainRoute {

    private Train train;
    private String number;
    private double cost;
    private Time departure;
    private int duration;
    private TrainStation source;
    private TrainStation destination;

    public TrainRoute() {
    }

    public TrainRoute(Train train, String number, double cost, Time departure, int duration, TrainStation source, TrainStation destination) {
        this.train = train;
        this.number = number;
        this.cost = cost;
        this.departure = departure;
        this.duration = duration;
        this.source = source;
        this.destination = destination;
    }

    public Train getTrain() {
        return train;
    }

    public TrainType getTrainType() {
        return this.train.getTrainType();
    }

    public String getNumber() {
        return number;
    }

    public double getCost() {
        return cost;
    }

    public TrainStation getDestination() {
        return destination;
    }

    public Time getDeparture() {
        return departure;
    }

    public Time getArrival() {
        //departure + duration
        Time arrival_time = new Time(getDeparture());
        arrival_time.addMinutes(duration);

        return arrival_time;
    }

    public String TravelTime() {
        String travel_time_str;
        int hrs;
        int mins;
        double d_hrs, d_mins;

        d_hrs = this.duration / 60.0;
        hrs = (int) d_hrs;
        d_mins = d_hrs - (int) d_hrs;
        mins = (int) ((d_mins * 60.0) + 0.5);

        travel_time_str = String.format("%dhr:%2dm", hrs, mins);
        return travel_time_str;
    }

    public TrainStation getSource() {
        return source;
    }

    public String toOverviewString() {
        //Get a currency formatter for the current locale.
        NumberFormat dollar_fmt = NumberFormat.getCurrencyInstance();

        String overview;
        String lcost = dollar_fmt.format(getCost());

        overview = String.format("%s\n%s - %s	%s\n%s            %s-%s", lcost, getDeparture(), getArrival(), TravelTime(),
                getTrainType(), getSource(), getDestination());

        return overview;
    }

    public String toDetailedString() {
        String details;

        details = String.format("%s - %s\n%s (%s)    -   %s (%s)\n%s %s",
                getDeparture(), getArrival(),
                getTrainStationCity(getSource()), getSource(), getTrainStationCity(getDestination()), getDestination(),
                getTrainType(), getNumber());
        return details;
    }

}
