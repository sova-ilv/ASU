package valdez_hw02;

/**
 * Train.java - A class that defines a traintype.
 *
 * @author Jess
 * @version (1.0)
 */
public class Train {

    private TrainType trainType;

    Train(TrainType trainType) {
        this.trainType = trainType;
    }

    public TrainType getTrainType() {
        return trainType;
    }

    public String toString() {
        return getTrainType() + " *";
    }
}
