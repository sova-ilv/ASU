/**
 * A java enumeration file - TrainType
 * Completion time : 10 minutes
 *
 * @author Jess Valdez
 * @version (1.0)
 */
package valdez_hw02;

public enum TrainType {
    InterCity,
    EuroCity,
    EuroStar;
}
